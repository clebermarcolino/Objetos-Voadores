public interface Voador {
    public double voar();
    public void planar();
    public boolean pousar();

}
